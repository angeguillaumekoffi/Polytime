package com.dexterous.flutterlocalnotifications;

public enum BitmapSource {
    DrawableResource,
    FilePath
}
