
import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:app/pages/ajouter.dart';
import 'pages/accueil.dart';
import 'pages/apropos.dart';
import 'pages/listtaches.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/cupertino.dart';
import 'db_test.dart';

class BottomNavBar extends StatefulWidget {

  @override
  _BottomNavBarState createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {

  final dbHelper = DatabaseHelper.instance;



   //Instanciation des differentes pages
  final Accueil _pagehome = new Accueil();
  final Apropos _pageapropos = new Apropos();
  final Ajouter _pageajouter = new Ajouter();
  final Mestaches _pagetaches = new Mestaches();

  //Construction de la page d'accueil
  Widget _afficherPage = new Accueil();
  Widget _choixdepage(int page){
    switch (page) {
      case 0:
        return _pageajouter;
        break;
      case 1:
        return _pagehome;
        break;
      case 2:
        return _pagetaches;
        break;
      case 3:
        return _pageapropos;
        break;

      default:
      return new  Container(
        child: new Center(
          child: new Text("ooops! La page souhaitée n'a pas été trouvée !",
          style: new TextStyle(fontSize: 28)),
        ),
      );
    }
  }
  GlobalKey _bottomNavigationKey = GlobalKey();
  bool switchChid = true;
  int pageIndex = 1;
  void initier(){
    setState((){
      _afficherPage = _pagehome;
      switchChid = !switchChid;
    });
  }

  void _initierCompteur() async{
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      prefs.setInt('counter', 1);
    });
  }

  @override
  void initState() {
    super.initState();

  }

  @override
  Widget build(BuildContext context) {


    return Scaffold(
        backgroundColor: const Color(0xFFeeeeee),
        bottomNavigationBar: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: <BoxShadow>[
              BoxShadow(blurRadius: 10.0, color: Colors.black, offset: Offset(2.0, 6.0))
            ],
          ),
          child: CurvedNavigationBar(
            key: _bottomNavigationKey,
            index: pageIndex,
            height: 55,//MediaQuery.of(context).size.height*0.08,
            items: <Widget>[
              Icon(Icons.add, size: 30),
              Icon(Icons.home, size: 30),
              Icon(Icons.date_range, size: 30),
              Icon(Icons.wb_incandescent, size: 30),
            ],
            color: Colors.white,
            buttonBackgroundColor: Colors.white,
            backgroundColor: Colors.black12,
            animationCurve: Curves.easeInOut,
            animationDuration: Duration(milliseconds: 600),
            onTap: (int indexselect) {
              _initierCompteur();
              setState(() {
                _afficherPage = _choixdepage(indexselect);
                switchChid = !switchChid;
              });
            },
          )
        ),
        body: AnimatedSwitcher(
          duration: Duration(seconds: 1),
          transitionBuilder: (Widget child, Animation<double>animation){
            return FadeTransition(opacity: animation, child: child,);
          },
          child: switchChid
          ?_afficherPage
          :_afficherPage,
        )
    );
  }

  //************************************************Module Notifications**********************************//


}