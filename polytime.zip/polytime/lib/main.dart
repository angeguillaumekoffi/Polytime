import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'pages/intro.dart';
import 'nav_bar.dart';
import 'db_test.dart';
import 'package:app/model/notification.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import 'package:foreground_service/foreground_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

//************************************Originaly coded by Ange Koffi**************************************************//
void lanceFGS() async{
  if(!(await ForegroundService.foregroundServiceIsStarted())){
    await ForegroundService.setServiceIntervalSeconds(5);
    await ForegroundService.notification.startEditMode();
    await ForegroundService.notification.setTitle("Polytime");
    await ForegroundService.notification.setText("Service en cours d'execution");
    await ForegroundService.notification.finishEditMode();

    await ForegroundService.startForegroundService(processus);
    await ForegroundService.getWakeLock();

  }
}

void processus() async{
  int actu;
  Timer.periodic(Duration(seconds: 1), (time) async{
    SharedPreferences prefs = await SharedPreferences.getInstance();
    actu = DateTime
        .now()
        .millisecondsSinceEpoch;
    final data = await DatabaseHelper.instance.chaqueTache();
    data.forEach((don) async {
      if (actu >= don.Heure && actu < don.Heure + 1600) {
        await FlutterRingtonePlayer.playAlarm(asAlarm: true);
        await LocalNotifications().createState().notification(
            "Tache : ${don.titre}",
            "Salut !\nVotre tâche prévue est arrivée !\nContenu : ${don
                .description}.");
        await prefs.setInt('alarme', 1);
      }
    });
    if ((await prefs.getInt('alarme') ?? 0) == 1) {
      await _eteindre;
      await prefs.setInt('alarme', 0);
    }
  });
}

Future _eteindre = Future.delayed(Duration(seconds: 30), () async{await FlutterRingtonePlayer.stop();});

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  //SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  runApp(new Polytime());

  lanceFGS();
  //isolate.kill();
  /*int actu;
  Timer.periodic(Duration(seconds: 1), (time) async{
    SharedPreferences prefs = await SharedPreferences.getInstance();
    actu = DateTime.now().millisecondsSinceEpoch;
    final data = await DatabaseHelper.instance.chaqueTache();
    data.forEach((don){
      if(actu >= don.Heure && actu < don.Heure+2000){
        print("Debut alarme");
        FlutterRingtonePlayer.playAlarm(asAlarm: true);
        LocalNotifications().createState().notification("Tache : ${don.titre}", "Salut !\nVotre tâche prévue est arrivée !\nContenu : ${don.description}.");
        prefs.setInt('alarme', 1);
      }
    });
    if((prefs.getInt('alarme') ?? 0) == 1){
      _eteindre;
      prefs.setInt('alarme', 0);
    }
  });*/
}

class Polytime extends StatelessWidget {

  final String _initialRoute = '/intro';
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Polytime',
      theme: ThemeData(
        primarySwatch: Colors.red,
        iconTheme: IconThemeData(color: Colors.red),
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: AppBarTheme(color: Colors.red),
      ),
      home: BottomNavBar(),
      initialRoute: _initialRoute,
      routes: {
        '/accueil': (context) => BottomNavBar(),
        '/intro': (context) => PageIntro(),
        'notif': (context) => LocalNotifications(),
      },
    );
  }
}
//***********************************Originaly coded by Ange Koffi**************************************************//