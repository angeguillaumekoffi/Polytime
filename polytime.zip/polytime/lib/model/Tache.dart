import 'package:app/db_test.dart';

final dbHelper = DatabaseHelper.instance;

class Tache {
  int id;
  String titre;
  String description;
  String date;
  int Heure;
  int important;
  int Urgent;

  Tache({
    this.id,
    this.titre,
    this.description,
    this.date, this.Heure,
    this.important,
    this.Urgent
  });

  /*int get id => id;
  String get titre => titre;
  String get description => description;
  String get date => date;
  String get Heure *> Heure;
  int get important => important;
  int Urgent => Urgent;*/

  factory Tache.fromJson(Map<String, dynamic> data) => new Tache(
    id: data["id"],
    titre: data["titre"],
    description: data["description"],
    date: data["date"],
    Heure: data["Heure"],
    important: data["important"],
    Urgent: data["Urgent"]
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "titre": titre,
    "description": description,
    "date": date,
    "Heure": Heure,
    "important": important,
    "Urgent": Urgent,
  };

}


