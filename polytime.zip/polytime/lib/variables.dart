import 'package:app/db_test.dart';

final dbHelper = DatabaseHelper.instance;

class Variables{
  static int _compteur;

  void _query() async {
    final allRows = await dbHelper.queryAllRows();
    print('query all rows:');
    allRows.forEach((row) => print(row));
  }

  void _update(_id, _titre, _desc, _date, _heure, _import, _urg) async {
    // row to update
    Map<String, dynamic> row = {
      DatabaseHelper.columnId   : _id,
      DatabaseHelper.columnNTitre : '$_titre',
      DatabaseHelper.columnDesc : '$_desc',
      DatabaseHelper.columnDate : '$_date',
      DatabaseHelper.columnHeure : '$_heure',
      DatabaseHelper.columnImportant : _import,
      DatabaseHelper.columnUrgent: _urg,
    };
    final rowsAffected = await dbHelper.update(row);
    print('updated $rowsAffected row(s)');
  }

  void _delete(_id) async {
    // Assuming that the number of rows is the id for the last row.
    //final id = await dbHelper.queryRowCount();
    final rowsDeleted = await dbHelper.delete(_id);
    print('deleted $rowsDeleted row(s): row $_id');
  }
}