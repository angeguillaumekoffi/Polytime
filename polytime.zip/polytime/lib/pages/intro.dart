import 'package:flutter/material.dart';
import 'package:intro_views_flutter/Models/page_view_model.dart';
import 'package:intro_views_flutter/intro_views_flutter.dart';
import 'package:app/nav_bar.dart';
import 'package:shared_preferences/shared_preferences.dart';

//************************************Originaly coded by Ange Koffi**************************************************//
class PageIntro extends StatefulWidget {
  @override
  _PageIntroState createState() => new _PageIntroState();
}

class _PageIntroState extends State<PageIntro> {
  int _compteur = 0;
  @override
  void initState() {
    super.initState();
  }

  void _reccuperCompteur() async{
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _compteur = (prefs.getInt('counter') ?? 0);
    });
  }

  Route _pageAccueil(){
    return PageRouteBuilder(
      transitionDuration: Duration(seconds: 1),
      pageBuilder: (context, animation, secondaryAnimation) => BottomNavBar(),
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        var begin = Offset(1.0, 0.0);
        var end = Offset.zero;
        var curve = Curves.ease;
        var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      }
    );
  }

  final pages = [
    PageViewModel(
        pageColor: const Color(0xFF542adf),
        //iconColor: const Color(0xFF000000),
        iconImageAssetPath: '',
        body: Table(
          children: [
            TableRow(children: [
              Text("Gérez votre temps!", textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 30)),
            ]),
            TableRow(children: [
              Text("Bienvenue sur l'application qui vous permettra de mieux gérer votre temps",style: TextStyle(color: Colors.white70, fontSize: 20)),
            ])
          ],
        ),
        title: Text("Polytime", style: TextStyle(color: Colors.white, fontSize: 18)),
        mainImage: Image.asset(
          'assets/images/intro/1.jpg',
          height: 285.0,
          width: double.infinity,
          alignment: Alignment.center,
        )),
    PageViewModel(
      pageColor: const Color(0xFFdd99de),
      iconImageAssetPath: '',
      body: Table(
          children: [
            TableRow(children: [
              Text("Emploi du temps", textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 30)),
            ]),
            TableRow(children: [
              Text("Construisez votre emploi du temps personnel et organisez vos TAF selon leur importance et leur urgence.",style: TextStyle(color: Colors.white70, fontSize: 20)),
            ])
          ],
        ),
      title: Text("Polytime", style: TextStyle(color: Colors.white, fontSize: 18)),
      mainImage: Image.asset(
        'assets/images/intro/urgent-important.png',
        //height: 285.0,
        width: double.infinity,
        alignment: Alignment.center,
      ),
      textStyle: TextStyle(color: Colors.white),
    ),

    PageViewModel(
      pageColor: const Color(0xFFFFFFFF),
      iconColor: const Color(0xFFFFFFFF),
      body:Table(
          children: [
            TableRow(children: [
              Text("Assistance automatique !", textAlign: TextAlign.center, style: TextStyle(color: Colors.black, fontSize: 25)),
            ]),
            TableRow(children: [
              Text( "Vous êses automatiquement notifié à l'approche du moment de l'exécution de la TAF et immédiatement alerté !",style: TextStyle(color: Colors.grey, fontSize: 20)),
            ])
          ],
          
        ),
      title: Text("Polytime", style: TextStyle(color: Colors.blueGrey, fontSize: 18)),
      mainImage: Image.asset(
        'assets/images/intro/concept_gt.jpg',
        //height: 285.0,
        width: double.infinity,
        alignment: Alignment.center,
      ),
      textStyle: TextStyle(color: Colors.grey),
    ),
  ];

  final BottomNavBar _pagehome = BottomNavBar();

  @override
  Widget build(BuildContext context) {
    Widget intro = Center(
        child: Scaffold(
          body:
          IntroViewsFlutter(
            pages,
            showNextButton: true,
            showSkipButton: true,
            showBackButton: false,
            skipText: const Text("Passer", style: TextStyle(color: Colors.white12)),
            doneText: const Text("Demarrer", style: TextStyle(color: Colors.deepPurple),),
            nextText: const Text("->>>", style: TextStyle(color: Colors.lightBlue),),
            onTapDoneButton: () {
              Navigator.of(context).push(_pageAccueil());
            },
          ),
        )
    );
    _reccuperCompteur();
    if(_compteur == 0){
      return intro;
    }else{ return _pagehome;}
  }
}
//************************************Originaly coded by Ange Koffi**************************************************//