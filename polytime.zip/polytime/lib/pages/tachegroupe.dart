import 'package:flutter/material.dart';


class Rubrique{
  //Rubrique._PrivateConstructor();

  static void _pageTache(BuildContext context) {
    Navigator.of(context).push(MaterialPageRoute(
        builder: (ctx) =>
            Scaffold(
              appBar: AppBar(backgroundColor: Colors.black,),
              backgroundColor: Colors.black,
              body: Center(
                child: Hero(
                  tag: 1,
                  child: Image(
                      width: MediaQuery
                          .of(context)
                          .size
                          .width,
                      image: AssetImage('assets/images/moi.png')),
                ),
              ),
            )
    ));
  }
}