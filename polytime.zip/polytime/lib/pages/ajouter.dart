import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:app/nav_bar.dart';
import 'package:app/db_test.dart';


//************************************Originaly coded by Ange Koffi**************************************************//
class Ajouter extends StatefulWidget {
  @override
  _AjouterState createState() => new _AjouterState();
}
class _AjouterState extends State<Ajouter> {
  final dbHelper = DatabaseHelper.instance;

  String la_date = ".. / .. / ..",
      lheure = ".. : ..";
  bool importance = false;
  bool urgence = false;
  int heure_sauv=0;
  var ret;
  final titre = TextEditingController();
  final descript = TextEditingController();

  @override
  void dispose_titre() {
    titre.dispose();
  }

  @override
  void dispose_desc() {
    descript.dispose();
  }

  String _timeToString(TimeOfDay now) {
    String timeString = "${now.hour.toString().padLeft(2, '0')}:${now.minute
        .toString().padLeft(2, '0')}";
    return timeString;
  }

  String _dateToString(DateTime now) {
    String dateString = "${now.day.toString().padLeft(2, '0')}/${now.month
        .toString().padLeft(2, '0')}/${now.year.toString().padLeft(2, '0')}";
    return dateString;
  }

  //Foction pour selectionner la date
  void _selDate() {
    DateTime actu = DateTime.now();
    showDatePicker(
        context: context,
        initialDate: actu,
        firstDate: DateTime(2019),
        lastDate: DateTime(2030)
    ).then((date) {
      //la valeur de retour est Date
      setState(() {
        la_date = _dateToString(date);
        print(la_date);
      });
    });
  }

  //Foction pour selectionner l'heure
  void _selHeure() {
    DateTime actu = new DateTime.now();
    showTimePicker(
        context: context,
        initialTime: TimeOfDay.now()
    ).then((Hr) {
      //la valeur de retour est Heure
      setState(() {
        lheure = _timeToString(Hr);
        heure_sauv = DateTime(actu.year, actu.month, actu.day, Hr.hour, Hr.minute).millisecondsSinceEpoch;
        print(heure_sauv);
      });
    });
  }

  //Fonction pour convertir bool en int
  int boolAint(bool val) {
    return val == true ? 1 : 0;
  }

  @override
  Widget build(BuildContext context) {

    //Champ de saisie du titre
    var saisie_titre = TextField(
        controller: titre,
        keyboardType: TextInputType.text,
        autofocus: false,
        decoration: InputDecoration(
          prefixIcon: Icon(Icons.text_fields, color: Colors.red),
          hintText: 'Titre de la tâche',
          contentPadding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 10.0),
          //border: UnderlineInputBorder(),
        )
    );

    //Champ de saisie de la description
    var saisie_desc = TextFormField(
        controller: descript,
        autofocus: false,
        maxLines: 8,
        minLines: 4,
        decoration: InputDecoration(
          prefixIcon: Icon(Icons.description, color: Colors.red),
          hintText: 'Description de la tâche',
          //contentPadding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 10.0),
          border: UnderlineInputBorder(),
        )
    );

    Future<int> _decompt = Future<int>.delayed(Duration(seconds: 3), () => 1);

    return Scaffold(
        appBar: AppBar(
          title: const Text("Nouvelle tâche"),
          centerTitle: true,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomRight: Radius.circular(20),
                bottomLeft: Radius.circular(20)),
          ),),
        body: Container(
          child: FutureBuilder<String>(
            future: Future<String>.delayed(Duration(seconds: 2), ()=> 'ok'),
            builder: (context, snapshot){
              if(snapshot.hasData){
                return ListView(
                  padding: EdgeInsets.only(left: 5.0, right: 5.0),
                  children: <Widget>[
                    Padding(
                      padding: EdgeInsets.only(top: 30, bottom: 10, left: 10),
                      child: Text('Tâche à faire', style: GoogleFonts.lato(
                        fontSize: 20, fontWeight: FontWeight.bold,)),
                    ),
                    Container(
                      padding: EdgeInsets.only(bottom: 20),
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          width: 0.3,
                          color: Color(0xFFb4b2b2),
                        ),
                      ),
                      child: Center(
                        child: saisie_titre,
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Container(
                      padding: EdgeInsets.only(bottom: 20),
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          width: 0.3,
                          color: Color(0xFFb4b2b2),
                        ),
                      ),
                      child: Center(
                        child: saisie_desc,
                      ),
                    ),

                    SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: EdgeInsets.only(bottom: 10, left: 10),
                      child: Text('Date et heure', style: GoogleFonts.lato(
                        fontSize: 20, fontWeight: FontWeight.bold,)),
                    ),
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          width: 0.3,
                          color: Color(0xFFb4b2b2),
                        ),
                      ),
                      child: Center(
                        child: Column(
                          children: <Widget>[
                            Container(
                              height: 60,
                              padding: EdgeInsets.only(right: 10),
                              width: double.infinity,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  width: 0.3,
                                  color: Color(0xFFb4b2b2),
                                ),
                              ),
                              child: GestureDetector(
                                child: Row(
                                  children: <Widget>[
                                    Container(
                                      height: 60,
                                      width: MediaQuery
                                          .of(context)
                                          .size
                                          .width * 1 / 3,
                                      decoration: BoxDecoration(
                                        color: Colors.blue.withOpacity(0.5),
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(20),
                                            bottomLeft: Radius.circular(20)),
                                      ),
                                      child: Center(
                                        child: Text('Date', style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold),),
                                      ),
                                    ),
                                    Spacer(),
                                    Text('$la_date', style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold),),
                                    Spacer(),
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: Icon(Icons.date_range, size: 40),
                                    ),
                                  ],
                                ),
                                onTap: _selDate,
                              ),
                            ),
                            SizedBox(height: 10,),
                            Container(
                              height: 60,
                              padding: EdgeInsets.only(right: 10),
                              width: double.infinity,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  width: 0.3,
                                  color: Color(0xFFb4b2b2),
                                ),
                              ),
                              child: GestureDetector(
                                child: Row(
                                  children: <Widget>[
                                    Container(
                                      height: 60,
                                      width: MediaQuery
                                          .of(context)
                                          .size
                                          .width * 1 / 3,
                                      decoration: BoxDecoration(
                                        color: Colors.indigo.withOpacity(0.5),
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(20),
                                            bottomLeft: Radius.circular(20)),
                                      ),
                                      child: Center(
                                        child: Text('Heure', style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold),),
                                      ),
                                    ),
                                    Spacer(),
                                    Text('$lheure', style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold),),
                                    Spacer(),
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: Icon(Icons.timer, size: 40),
                                    ),
                                  ],
                                ),
                                onTap: _selHeure,),
                            ),
                          ],
                        ),
                      ),
                    ),

                    SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: EdgeInsets.only(bottom: 10, left: 10),
                      child: Text('Priorité', style: GoogleFonts.lato(
                        fontSize: 20, fontWeight: FontWeight.bold,)),
                    ),
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          width: 0.3,
                          color: Color(0xFFb4b2b2),
                        ),
                      ),
                      child: Center(
                        child: Column(
                          children: <Widget>[
                            SwitchListTile(
                              title: Text("Important"),
                              value: importance,
                              secondary: Icon(
                                Icons.label_important, color: Colors.red,),
                              onChanged: (value) {
                                setState(() {
                                  importance = value;
                                });
                              },
                            ),
                            Divider(),
                            SwitchListTile(
                              title: Text("Urgent"),
                              value: urgence,
                              secondary: Icon(Icons.warning, color: Colors.red),
                              onChanged: (value) {
                                setState(() {
                                  urgence = value;
                                });
                              },
                            )
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,

                    ),
                    RaisedButton(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        padding: EdgeInsets.all(15),
                        child: Text('Enregistrer', style: TextStyle(color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.normal),),
                        color: Colors.red,
                        onPressed: () {
                          Scaffold.of(context).showSnackBar(
                              SnackBar(
                                backgroundColor: Colors.black12,
                                //duration: Duration(milliseconds: 5200),
                                content: FutureBuilder<int>(
                                  future: _decompt,
                                  builder: (BuildContext context,
                                      AsyncSnapshot<int>snapshot) {
                                    List<Widget>children;
                                    if (snapshot.hasData) {
                                      children = <Widget>[
                                        Icon(Icons.check_circle_outline, color: Colors
                                            .green, size: 50,),
                                        Padding(
                                          padding: const EdgeInsets.only(top: 16),
                                          child: Text('Tâche ' + titre.text +
                                              ' ajoutée avec succès !'),
                                        )
                                      ];
                                    } else if (snapshot.hasError) {
                                      children = <Widget>[
                                        Icon(Icons.check_circle_outline,
                                          color: Colors.red, size: 50,),
                                        Padding(
                                          padding: const EdgeInsets.only(top: 16),
                                          child: Text('Erreur ! ${snapshot.error}'),
                                        )
                                      ];
                                    } else {
                                      children = <Widget>[
                                        SizedBox(
                                          child: CircularProgressIndicator(),
                                          width: 40,
                                          height: 40,
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(top: 16),
                                          child: Text('Enregistrement...'),
                                        )
                                      ];
                                      _insert(titre.text, descript.text, la_date, heure_sauv, boolAint(importance), boolAint(urgence));
                                    }
                                    return Center(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: children,
                                      ),
                                    );
                                  },
                                ),
                              )
                          );
                        }
                    ),
                    SizedBox(
                      height: 30,
                    ),
                  ],
                );
              }else{
                return Container( alignment: AlignmentDirectional.center, child: CircularProgressIndicator(),);
              }
            }
          ),
        )
    );
  }

  _insert(_titre, _desc, _date, _heure, _import, _urg) async {
    // row to insert
    Map<String, dynamic> row = {
      DatabaseHelper.columnNTitre: '$_titre',
      DatabaseHelper.columnDesc: '$_desc',
      DatabaseHelper.columnDate: '$_date',
      DatabaseHelper.columnHeure: '$_heure',
      DatabaseHelper.columnImportant: _import,
      DatabaseHelper.columnUrgent: _urg,
    };
    //final id = await dbHelper.insert(row);
    if(await dbHelper.insert(row) > 0){
      setState(() {
        ret = 1;
      });
    }else{
      setState(() {
        ret = null;
      });
    }
  }
}
//************************************Originaly coded by Ange Koffi**************************************************//